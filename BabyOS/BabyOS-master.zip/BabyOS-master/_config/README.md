# 配置工具使用说明

## Python环境

确保已有python环境，如若没有请安装(Python 2 或 Python 3)：

https://www.python.org/

将以下目录添加至环境变量：

python.exe所在目录 (Python\Python311\)

pip.exe所在目录      （Python\Python311\Scripts）

根据实际情况添加。



## bos目录相对路径

默认bos相对路径是 ../bos

如果实际情况与此不同，请修改b_config.bat

```c
set bos_path=../bos   //此处../bos改为实际的相对路径
```



## 开始配置



双击 b_config.bat