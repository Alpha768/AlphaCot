#ifndef __B_DRV_QMI8658A_H__
#define __B_DRV_QMI8658A_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------*/
#include "drivers/inc/b_driver.h"

/**
 * \defgroup QMI8658A_Exported_TypesDefinitions
 * \{
 */
typedef bHalI2CIf_t bQMI8658A_HalIf_t;

/**
 * }
 */

/**
 * \defgroup QMI8658A_Exported_Defines
 * \{
 */

/**
 * }
 */

/**
 * \defgroup QMI8658A_Exported_Macros
 * \{
 */

/**
 * }
 */

/**
 * \defgroup QMI8658A_Exported_Functions
 * \{
 */

/**
 * }
 */

/**
 * }
 */

/**
 * }
 */

/**
 * }
 */

#ifdef __cplusplus
}
#endif

#endif /* __B_DRV_QMI8658A_H__ */

/***** Copyright (c) 2023 miniminiminini *****END OF FILE*****/
