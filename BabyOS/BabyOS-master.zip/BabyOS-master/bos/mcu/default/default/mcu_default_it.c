#include "b_config.h"
#include "hal/inc/b_hal_it.h"

void bMcuIntEnable()
{
    ;
}

void bMcuIntDisable()
{
    ;
}

