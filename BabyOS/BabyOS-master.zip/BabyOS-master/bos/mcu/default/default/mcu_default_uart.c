#include "b_config.h"
#include "hal/inc/b_hal_uart.h"

int bMcuUartSend(bHalUartNumber_t uart, const uint8_t *pbuf, uint16_t len)
{
    return -1;
}

