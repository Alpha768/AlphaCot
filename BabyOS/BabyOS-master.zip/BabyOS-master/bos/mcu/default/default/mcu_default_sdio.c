#include "b_config.h"
#include "hal/inc/b_hal_sdio.h"

int bMcuSDIOReadBlocks(const bHalSDIONumber_t sd, uint8_t *pdata, uint32_t addr,
                                 uint32_t xblocks)
{
    return 0;
}

int bMcuSDIOWriteBlocks(const bHalSDIONumber_t sd, uint8_t *pdata, uint32_t addr,
                                  uint32_t xblocks)
{
    return 0;
}

