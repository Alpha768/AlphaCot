#include "b_config.h"
#include "hal/inc/b_hal_wdt.h"

int bMcuWdtStart(uint8_t timeout_s)
{
    return -1;
}

int bMcuWdtFeed()
{
    return -1;
}

