# ifndef COT_PREPROCESSOR_CAT_H
# define COT_PREPROCESSOR_CAT_H

# define COT_PP_CAT(a, b) COT_PP_CAT_I(a, b)
# define COT_PP_CAT_I(a, b) a ## b

# endif