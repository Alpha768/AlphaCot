/**
  **********************************************************************************************************************
  * @file    cot_os_config.h
  * @brief   该文件提供查询协作式多任务系统功能函数原型
  * @author  const_zpc    any question please send mail to const_zpc@163.com
  * @date    2023-10-17
  **********************************************************************************************************************
  *
  **********************************************************************************************************************
  */

/* Define to prevent recursive inclusion -----------------------------------------------------------------------------*/
#ifndef _COT_OS_CONFIG_H_
#define _COT_OS_CONFIG_H_

/**
  * @brief  定义可创建的最大的任务数目
  * @note   独立栈任务和共享栈任务总和
  */
#define COT_OS_MAX_TASK                     10

/**
  * @brief  定义可创建的最大的共享栈任务数目
  * @attention 不能大于总任务数目
  */
#define COT_OS_MAX_SHARED_TASK              2

/**
  * @brief  定义单个共享栈任务栈备份的空间大小
  */
#define COT_OS_MAX_SHARED_BAK_STACK_SIZE    256

/**
  * @brief  定义任务名字最大长度
  * 
  */
#define COT_OS_TASK_NAME_LENGTH             8

/**
  * @brief   根据不同平台定义堆栈获取和设置指针
  * 
  */
#define COT_OS_GET_STACK(p)        __asm__ volatile("mov %%rsp, %0" : "=r" (p));
#define COT_OS_SET_STACK(p)        __asm__ volatile("mov %0, %%rsp" : : "r" (p) : "memory");

#endif


