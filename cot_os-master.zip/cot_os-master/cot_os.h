/**
  **********************************************************************************************************************
  * @file    cot_os.h
  * @brief   该文件提供查询协作式多任务系统功能函数原型
  * @author  const_zpc    any question please send mail to const_zpc@163.com
  * @date    2024-10-17
  **********************************************************************************************************************
  *
  **********************************************************************************************************************
  */

/* Define to prevent recursive inclusion -----------------------------------------------------------------------------*/
#ifndef _COT_OS_H_
#define _COT_OS_H_

/* Includes ----------------------------------------------------------------------------------------------------------*/
#include <stdint.h>
#include <stddef.h>


// 定义一个OS预编译宏
#define _COT_OS_

/* Exported types ----------------------------------------------------------------------------------------------------*/

typedef void (*cotOsTask_f)(int);
typedef uint32_t (*cotOsGetSysTime_f)(void);

typedef struct
{
    uint8_t flag;
}CotOSCondition_t;

/**
  * @brief      任务栈类型
  * 
  */
typedef enum
{
    COT_OS_UNIQUE_STACK = 0,            /*!(0) 独立栈 */
    COT_OS_SHARED_STACK                 /*!(1) 共享栈 */
} CotOSStackType_e;

typedef void* cotOsTask_t;

/* Exported constants ------------------------------------------------------------------------------------------------*/
/* Exported macro ----------------------------------------------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------------------------------------------------*/

extern void cotOs_Init(cotOsGetSysTime_f pfnOsTimer);
extern void cotOs_SharedStack(const void *pStack, size_t stackSize);
extern int cotOs_Start(void);

extern cotOsTask_t cotOs_CreatTask(cotOsTask_f pfnOsTaskEnter, const char *pName, CotOSStackType_e eStackType, void *pStack, size_t stackSize, int arg);
extern void cotOs_Wait(uint32_t time);
extern void cotOs_Join(cotOsTask_t task);

extern uint16_t cotOs_Pid(void);

extern void cotOs_ConditionInit(CotOSCondition_t *pCondition);
extern void cotOs_ConditionWait(CotOSCondition_t *pCondition);
extern void cotOs_ConditionNotify(CotOSCondition_t *pCondition);

extern void cotOs_Top(void);

#endif // !_COT_TASK_H_
