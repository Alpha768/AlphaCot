/**
  **********************************************************************************************************************
  * @file    cot_os.c
  * @brief   该文件提供查询协作式多任务系统功能
  * @author  const_zpc  any question please send mail to const_zpc@163.com
  * @version V1.1.0
  * @date    2024-10-17
  *
  * @details  功能详细说明：
  *           + 任务调度初始化
  *           + 任务调度功能启动
  *           + 该任务调度并非抢占式
  *
  **********************************************************************************************************************
  * 源码路径：https://gitee.com/cot_package/cot_os.git 具体问题及建议可在该网址填写 Issue
  *
  * 使用方式:
  *    1. 使用前初始化函数 cotOs_Init
  *    2. 通过 cotOs_Creat 添加任务函数
  *    3. 主函数调用 cotOs_Start 启动任务调度, 函数不会退出
  *    4. 使用 cotOs_Wait 切换到下一个任务执行
  *
  **********************************************************************************************************************
  */

/* Includes ----------------------------------------------------------------------------------------------------------*/

#include <stdbool.h>
#include "cot_os_config.h"
#include <setjmp.h>
#include "cot_os.h"

/* Private typedef ---------------------------------------------------------------------------------------------------*/

#if (COT_OS_MAX_TASK > 32)
#error "task max num can't over 32"
#endif

#if (COT_OS_MAX_SHARED_TASK > COT_OS_MAX_TASK)
#error "shared task max num can't over task max num"
#endif

typedef struct stTCB
{
    char szName[COT_OS_TASK_NAME_LENGTH];
    uint16_t pid;
    uint8_t state : 3;
    uint8_t joinWaitCnt :5;
    CotOSCondition_t cond;
    CotOSStackType_e eStackType;
    uint32_t nextRunTime;
    int param;
    jmp_buf env;
    cotOsTask_f pfnOsTaskEnter;
    CotOSCondition_t *pCondition;
#if COT_OS_MAX_SHARED_TASK > 0
    uint8_t *pBakStack;
#endif
    struct stTCB *pNext;
} TCB_t;

/**
  * @brief 中断任务信息结构体定义
  */
typedef struct
{
    cotOsGetSysTime_f pfnGetTimerMs;                /*!< 获取毫秒级别的时间回调函数 */

    TCB_t *pCurTCB;

    TCB_t *pTCBList;
#if COT_OS_MAX_SHARED_TASK > 0
    size_t sharedStackTop;

    uint32_t tcbStackMask;
#endif
    uint32_t tcbMask;

    jmp_buf env;

    jmp_buf envResume;

    uint16_t pidCount;
} OsInfo_t;

/* Private define ----------------------------------------------------------------------------------------------------*/

#define COMMON_TASK_INTI                0
#define COMMON_TASK_RUN                 1

#define MAIN_TASK_INTI                  0
#define MAIN_TASK_EXIT                  1
#define MAIN_TASK_JUMP_SHARED_TASK      2

#define TASK_STATUS_READY               0
#define TASK_STATUS_RUNNING             1
#define TASK_STATUS_SUSPEND             2
#define TASK_STATUS_DELETED             3

/* Private macro -----------------------------------------------------------------------------------------------------*/
/* Private variables -------------------------------------------------------------------------------------------------*/

static OsInfo_t sg_OsInfo;
static TCB_t sg_TCB[COT_OS_MAX_TASK];
#if COT_OS_MAX_SHARED_TASK > 0
static uint8_t sg_shareTCBStack[COT_OS_MAX_SHARED_TASK][COT_OS_MAX_SHARED_BAK_STACK_SIZE];
#endif

/* Private function prototypes ---------------------------------------------------------------------------------------*/
static void MaxStrpy(char *out, const char *in, size_t maxLength);
static TCB_t *CreatTCB(OsInfo_t *pObj);
static void DestroyTCB(OsInfo_t *pObj, TCB_t *pCurTCB);
#if COT_OS_MAX_SHARED_TASK > 0
static uint8_t *CreatTCBStack(OsInfo_t *pObj);
static void DestroyTCBStack(OsInfo_t *pObj, TCB_t *pCurTCB);
#endif
static void AddToTCBTaskList(OsInfo_t *pObj, TCB_t *pNewTCB);
static void DeleteFromTCBTaskList(OsInfo_t *pObj, TCB_t *pCurTCB);
static uint8_t GetTaskNum(OsInfo_t *pObj);
static void DestoryTask(OsInfo_t *pObj, TCB_t *pCurTCB);
static void RunTask(OsInfo_t *pOsInfo);
static void JumpNextTask(OsInfo_t *pObj);

/* Private function --------------------------------------------------------------------------------------------------*/
static void MaxStrpy(char *out, const char *in, size_t maxLength)
{
    while (*in != '\0' && maxLength > 1)
    {
        *out = *in;
        out++;
        in++;
        maxLength--;
    }

    *out = '\0';
}

static void TcbMemcpy(uint8_t *pdest, uint8_t *psrc, size_t length)
{
    while (length--)
    {
        *pdest = *psrc;
        pdest++;
        psrc++;
    }
}

static TCB_t *CreatTCB(OsInfo_t *pObj)
{
    for (int i = 0; i < COT_OS_MAX_TASK; i++)
    {
        if (!((pObj->tcbMask >> i) & 0x01))
        {
            pObj->tcbMask |= (0x1 << i);
            return &sg_TCB[i];
        }
    }

    return NULL;
}

static void DestroyTCB(OsInfo_t *pObj, TCB_t *pCurTCB)
{
    for (int i = 0; i < COT_OS_MAX_TASK; i++)
    {
        if (&sg_TCB[i] == pCurTCB)
        {
            pObj->tcbMask &= ~(0x1 << i);
            break;
        }
    }
}

#if COT_OS_MAX_SHARED_TASK > 0
static uint8_t *CreatTCBStack(OsInfo_t *pObj)
{
    for (int i = 0; i < COT_OS_MAX_SHARED_TASK; i++)
    {
        if (!((pObj->tcbStackMask >> i) & 0x01))
        {
            pObj->tcbStackMask |= (0x1 << i);
            return sg_shareTCBStack[i];
        }
    }

    return NULL;
}

static void DestroyTCBStack(OsInfo_t *pObj, TCB_t *pCurTCB)
{
    for (int i = 0; i < COT_OS_MAX_SHARED_TASK; i++)
    {
        if (sg_shareTCBStack[i] == pCurTCB->pBakStack)
        {
            pObj->tcbStackMask &= ~(0x1 << i);
            break;
        }
    }
}
#endif

static void AddToTCBTaskList(OsInfo_t *pObj, TCB_t *pNewTCB)
{
    if (pObj->pTCBList == NULL)
    {
        pObj->pTCBList = pNewTCB;
        pObj->pTCBList->pNext = pObj->pTCBList;
    }
    else
    {
        TCB_t *pTCB = pObj->pTCBList;

        while (pTCB->pNext != NULL && pTCB->pNext != pObj->pTCBList)
        {
            pTCB = pTCB->pNext;
        }

        pNewTCB->pNext = pTCB->pNext;
        pTCB->pNext = pNewTCB;
    }
}

static void DeleteFromTCBTaskList(OsInfo_t *pObj, TCB_t *pCurTCB)
{
    TCB_t *pTCB = pObj->pTCBList;

    if (pTCB->pNext == pObj->pTCBList)
    {
        pObj->pTCBList = NULL;
    }
    else
    {
        while (pTCB->pNext != pObj->pTCBList)
        {
            if (pTCB->pNext == pCurTCB)
            {
                break;
            }

            pTCB = pTCB->pNext;
        }

        pTCB->pNext = pCurTCB->pNext;

        if (pCurTCB == pObj->pTCBList)
        {
            pObj->pTCBList = pCurTCB->pNext;
        }
    }
}

static uint8_t GetTaskNum(OsInfo_t *pObj)
{
    uint8_t num = 0;
    TCB_t *pTCB = sg_OsInfo.pTCBList;

    if (pTCB == NULL)
    {
        return 0;
    }

    do {
        if (pTCB->state != TASK_STATUS_DELETED)
        {
            num++;
        }

        pTCB = pTCB->pNext;
    } while (pTCB != sg_OsInfo.pTCBList);

    return num;
}

/**
  * @brief      初始化协程OS系统
  * 
  * @attention  回调函数不可为NULL
  * @param      pfOsTimer 获取毫秒级别的时间回调函数
  */
void cotOs_Init(cotOsGetSysTime_f pfnOsTimer)
{
    sg_OsInfo.pfnGetTimerMs = pfnOsTimer;
    sg_OsInfo.pTCBList = NULL;
    sg_OsInfo.pCurTCB = NULL;
#if COT_OS_MAX_SHARED_TASK > 0
    sg_OsInfo.sharedStackTop = 0;
    sg_OsInfo.tcbStackMask = 0;
#endif
    sg_OsInfo.tcbMask = 0;
    sg_OsInfo.pidCount = 0;
}

#if COT_OS_MAX_SHARED_TASK > 0
/**
  * @brief      设置任务的共享栈空间
  * 
  * @param      pStack         栈空间
  * @param      stackSize      栈空间大小
  */
void cotOs_SharedStack(const void *pStack, size_t stackSize)
{
    sg_OsInfo.sharedStackTop = (size_t)((const uint8_t *)pStack + stackSize);
}
#endif

static void DestoryTask(OsInfo_t *pObj, TCB_t *pCurTCB)
{
    if (pCurTCB->state == TASK_STATUS_DELETED && pCurTCB->joinWaitCnt == 0)
    {
#if COT_OS_MAX_SHARED_TASK > 0
        DestroyTCBStack(&sg_OsInfo, pCurTCB);
#endif
        DeleteFromTCBTaskList(&sg_OsInfo, pCurTCB);
        DestroyTCB(&sg_OsInfo, pCurTCB);
    }
}

static void RunTask(OsInfo_t *pOsInfo)
{
    sg_OsInfo.pCurTCB->state = TASK_STATUS_RUNNING;
    sg_OsInfo.pCurTCB->pfnOsTaskEnter(sg_OsInfo.pCurTCB->param);
    sg_OsInfo.pCurTCB->state = TASK_STATUS_DELETED;
    cotOs_ConditionNotify(&sg_OsInfo.pCurTCB->cond);
    DestoryTask(&sg_OsInfo, sg_OsInfo.pCurTCB);

    if (GetTaskNum(&sg_OsInfo) > 0)
    {
        JumpNextTask(&sg_OsInfo);
    }
    else
    {
        longjmp(sg_OsInfo.env, MAIN_TASK_EXIT);
    }
}

/**
  * @brief      创建任务
  * 
  * @attention  不能在共享栈任务创建共享栈任务
  * @attention  同一个栈空间不能同时设置为共享栈和独立栈，即共享栈任务和独立栈任务不能使用相同的栈空间
  * @attention  若选择共享栈，则使用`cotOs_Wait`和`cotOs_ConditionWait`仅限于在任务函数中使用，禁止在任务函数中的嵌套函数中使用
  * @note       独立栈任务必须有不同的栈空间，而共享栈任务可以有相同的栈空间
  * @param      pfnOsTaskEnter 任务入口函数
  * @param      eStackType     栈类型选择
  * @param      pStack         栈空间，选择共享栈是该值为NULL
  * @param      stackSize      栈空间大小，选择共享栈是该值为0
  * @param      arg            任务入口函数参数
  * @return     任务句柄, 为NULL则创建失败
  */
cotOsTask_t cotOs_CreatTask(cotOsTask_f pfnOsTaskEnter, const char *pName, CotOSStackType_e eStackType, void *pStack, size_t stackSize, int arg)
{
    // 防止设置新的堆栈后该变量生命周期失效
    static TCB_t *s_pNewTCB = NULL;
    static jmp_buf s_creatTaskEnv;

    if (sg_OsInfo.pfnGetTimerMs == NULL)
    {
        return NULL;
    }

    if (eStackType == COT_OS_UNIQUE_STACK && (pStack == NULL || stackSize == 0))
    {
        return NULL;
    }
#if COT_OS_MAX_SHARED_TASK > 0
    if (eStackType == COT_OS_SHARED_STACK && sg_OsInfo.sharedStackTop == 0)
    {
        return NULL;
    }
#else
    if (eStackType == COT_OS_SHARED_STACK)
    {
        return NULL;
    }
#endif
    // 禁止在共享栈任务创建共享栈任务
    if (sg_OsInfo.pCurTCB != NULL && sg_OsInfo.pCurTCB->eStackType == COT_OS_SHARED_STACK && eStackType == COT_OS_SHARED_STACK)
    {
        return NULL;
    }

    s_pNewTCB = CreatTCB(&sg_OsInfo);

    if (NULL == s_pNewTCB)
    {
        return NULL;
    }

    MaxStrpy(s_pNewTCB->szName, pName, sizeof(s_pNewTCB->szName));
    s_pNewTCB->pid = sg_OsInfo.pidCount++;
    s_pNewTCB->pfnOsTaskEnter = pfnOsTaskEnter;
    s_pNewTCB->param = arg;
    s_pNewTCB->eStackType = eStackType;
    s_pNewTCB->pNext = NULL;
    s_pNewTCB->state = TASK_STATUS_READY;
    s_pNewTCB->pCondition = NULL;
#if COT_OS_MAX_SHARED_TASK > 0
    s_pNewTCB->pBakStack = eStackType == COT_OS_SHARED_STACK ? CreatTCBStack(&sg_OsInfo) : NULL;
#endif
    s_pNewTCB->nextRunTime = 0;
    s_pNewTCB->joinWaitCnt = 0;
    cotOs_ConditionInit(&s_pNewTCB->cond);

    if (eStackType == COT_OS_UNIQUE_STACK)
    {
        if (0 == setjmp(s_creatTaskEnv))
        {
            COT_OS_SET_STACK(((size_t)pStack + stackSize));

            if (COMMON_TASK_INTI == setjmp(s_pNewTCB->env))
            {
                // 设置新的栈顶后记录创建任务的入口后返回原来的任务栈继续运行
                longjmp(s_creatTaskEnv, 1);
            }
            else
            {
                RunTask(&sg_OsInfo);
            }
        }
    }
    else
    {
#if COT_OS_MAX_SHARED_TASK > 0
        if (s_pNewTCB->pBakStack == NULL)
        {
            DestroyTCB(&sg_OsInfo, sg_OsInfo.pCurTCB);
            return NULL;
        }

        if (0 == setjmp(s_creatTaskEnv))
        {
            COT_OS_SET_STACK(sg_OsInfo.sharedStackTop);

            if (COMMON_TASK_INTI == setjmp(s_pNewTCB->env))
            {
                longjmp(s_creatTaskEnv, 1);
            }
            else
            {
                RunTask(&sg_OsInfo);
            }
        }
#endif
    }

    AddToTCBTaskList(&sg_OsInfo, s_pNewTCB);

    return s_pNewTCB;
}
/**
  * @brief      启动协程OS任务
  * 
  * @attention  该函数不会退出, 因此一切准备就绪后最后调用该函数即可
  * @return     0,成功; -1,失败
  */
int cotOs_Start(void)
{
    if (sg_OsInfo.pTCBList == NULL || sg_OsInfo.pfnGetTimerMs == NULL)
    {
        return -1;
    }

    int ret = setjmp(sg_OsInfo.env);

    if (MAIN_TASK_INTI == ret)
    {
        sg_OsInfo.pCurTCB = sg_OsInfo.pTCBList;
        longjmp(sg_OsInfo.pCurTCB->env, COMMON_TASK_RUN);
    }
#if COT_OS_MAX_SHARED_TASK > 0
    else if (MAIN_TASK_JUMP_SHARED_TASK == ret)
    {
        TcbMemcpy((uint8_t *)(sg_OsInfo.sharedStackTop - COT_OS_MAX_SHARED_BAK_STACK_SIZE), 
            sg_OsInfo.pCurTCB->pBakStack,  COT_OS_MAX_SHARED_BAK_STACK_SIZE);
        longjmp(sg_OsInfo.pCurTCB->env, COMMON_TASK_RUN);
    }
#endif
    return 0;
}

static void JumpNextTask(OsInfo_t *pObj)
{
    if (pObj->pTCBList != NULL)
    {
        while (1)
        {
            TCB_t *pTCB = pObj->pTCBList;

            do {
                if (pTCB->state != TASK_STATUS_DELETED)
                {
                    if (((pTCB->nextRunTime != 0 && pObj->pfnGetTimerMs() > pTCB->nextRunTime) || 
                        (pTCB->pCondition != NULL && pTCB->pCondition->flag == 1)))
                    {
                        pTCB->state = TASK_STATUS_READY;
                    }
                }

                pTCB = pTCB->pNext;
            } while (pTCB != pObj->pTCBList);

            do {
                if (pTCB->pCondition != NULL)
                    pTCB->pCondition->flag = 0;

                pTCB = pTCB->pNext;
            } while (pTCB != pObj->pTCBList);

            pTCB = pObj->pCurTCB->pNext;

            do {
                if (pTCB->state == TASK_STATUS_READY)
                {
                    pObj->pCurTCB = pTCB;
                    pObj->pCurTCB->state = TASK_STATUS_RUNNING;
#if COT_OS_MAX_SHARED_TASK > 0
                    if (pObj->pCurTCB->pBakStack != NULL)
                    {
                        longjmp(sg_OsInfo.env, MAIN_TASK_JUMP_SHARED_TASK);
                    }
                    else
#endif
                    {
                        longjmp(pObj->pCurTCB->env, COMMON_TASK_RUN);
                    }
                }

                pTCB = pTCB->pNext;
            } while (pTCB != pObj->pCurTCB->pNext);
        }
    }
}

/**
  * @brief      任务阻塞等待时间结束
  * 
  * @note       等待n毫秒时长, 则会在 >= n 后的某个时刻才会运行, 具体要看其他协程任务什么时候让出资源
  * @param      time 等待时长，单位毫秒
  */
void cotOs_Wait(uint32_t time)
{
    sg_OsInfo.pCurTCB->nextRunTime = sg_OsInfo.pfnGetTimerMs() + time;
    sg_OsInfo.pCurTCB->pCondition = NULL;
    sg_OsInfo.pCurTCB->state = TASK_STATUS_SUSPEND;

    if (COMMON_TASK_RUN != setjmp(sg_OsInfo.pCurTCB->env))
    {
#if COT_OS_MAX_SHARED_TASK > 0
        if (sg_OsInfo.pCurTCB->pBakStack != NULL)
        {
            TcbMemcpy(sg_OsInfo.pCurTCB->pBakStack, 
                (uint8_t *)(sg_OsInfo.sharedStackTop - COT_OS_MAX_SHARED_BAK_STACK_SIZE), COT_OS_MAX_SHARED_BAK_STACK_SIZE);
        }
#endif
        JumpNextTask(&sg_OsInfo);
    }
}

/**
  * @brief      等待任务退出
  * 
  * @param      task cotOs_CreatTask 返回的值
  */
void cotOs_Join(cotOsTask_t task)
{
    TCB_t *pTaskTCB = (TCB_t *)task;
    TCB_t *pTCB = sg_OsInfo.pTCBList;

    if (NULL != pTaskTCB)
    {
        do {
            if (pTCB == pTaskTCB && pTaskTCB->state != TASK_STATUS_DELETED)
            {
                pTCB->joinWaitCnt++;
                cotOs_ConditionWait(&pTaskTCB->cond);
                pTCB->joinWaitCnt--;
                DestoryTask(&sg_OsInfo, pTCB);
                break;
            }

            pTCB = pTCB->pNext;
        } while (pTCB != sg_OsInfo.pTCBList);
    }
}

/**
  * @brief      获取当前任务的ID
  * 
  * @return     uint16_t 
  */
uint16_t cotOs_Pid(void)
{
    return sg_OsInfo.pCurTCB->pid;
}

/**
  * @brief      条件事件初始化
  * 
  * @param      pCondition 条件事件
  */
void cotOs_ConditionInit(CotOSCondition_t *pCondition)
{
    if (pCondition == NULL)
    {
        return;
    }

    pCondition->flag = 0;
}

/**
  * @brief      任务阻塞等待条件事件发生
  * 
  * @note       等待条件事件发生, 则会在条件事件发生后的某个时刻才会运行, 具体要看其他协程任务什么时候让出资源
  * @param      pCondition 条件事件
  */
void cotOs_ConditionWait(CotOSCondition_t *pCondition)
{
    if (pCondition == NULL)
    {
        return;
    }

    sg_OsInfo.pCurTCB->nextRunTime = 0;
    sg_OsInfo.pCurTCB->pCondition = pCondition;
    sg_OsInfo.pCurTCB->state = TASK_STATUS_SUSPEND;

    int ret = setjmp(sg_OsInfo.pCurTCB->env);

    if (COMMON_TASK_RUN != ret)
    {
        JumpNextTask(&sg_OsInfo);
    }
}

/**
  * @brief      触发条件事件
  * 
  * @param      pCondition 条件事件
  */
void cotOs_ConditionNotify(CotOSCondition_t *pCondition)
{
    if (pCondition == NULL)
    {
        return;
    }

    pCondition->flag = 1;
}

#if 0
#include <stdio.h>

#define GET_STATUS(state)  (state) == TASK_STATUS_READY ? "R" : \
    ((state) == TASK_STATUS_RUNNING ? "X" : \
    ((state) == TASK_STATUS_SUSPEND ? "S" : "D"))

void cotOs_Top(void)
{
    printf("%3s  %-16s %-1s\n", "pid", "name", "state");

    for (int i = 0; i < COT_OS_MAX_TASK; i++)
    {
        if (((sg_OsInfo.tcbMask >> i) & 0x01))
        {
            printf("%3d  %-16s %-1s\n", sg_TCB[i].pid, sg_TCB[i].szName, GET_STATUS(sg_TCB[i].state));
        }
    }
}
#endif